/* SCCS-info %W% %E% */
/*--------------------------------------------------------------------*/
/*                                                                    */
/*              VCG : Visualization of Compiler Graphs                */
/*              --------------------------------------                */
/*                                                                    */
/*   file:         This file is uglified by UGLIFIER V 1.0            */
/*   version:      1.00.00                                            */
/*   author:       I. Lemke  (...-Version 0.99.99)                    */
/*                 G. Sander (Version 1.00.00-...)                    */
/*                 Universitaet des Saarlandes, 66041 Saarbruecken    */
/*                 ESPRIT Project #5399 Compare                       */
/*--------------------------------------------------------------------*/


/*
 *   Copyright (C) 1993-2005 Saarland University
 *
 *  This program and documentation is free software; you can redistribute
 *  it under the terms of the  GNU General Public License as published by
 *  the  Free Software Foundation;  either version 2  of the License,  or
 *  (at your option) any later version.
 *
 *  This  program  is  distributed  in  the hope that it will be useful,
 *  but  WITHOUT ANY WARRANTY;  without  even  the  implied  warranty of
 *  MERCHANTABILITY  or  FITNESS  FOR  A  PARTICULAR  PURPOSE.  See  the
 *  GNU General Public License for more details.
 *
 *  You  should  have  received a copy of the GNU General Public License
 *  along  with  this  program;  if  not,  write  to  the  Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */


/*--------------------------------------------------------------------*/


#ifndef lint
static char *gs_ide26 = "$Id: step1.c,v 3.11 1995/02/08 11:11:14 sander Exp $";
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "globals.h"
#include "alloc.h"
#include "main.h"
#include "options.h"
#include "timelim.h"
#include "folding.h"
#include "steps.h"
#include "timing.h"

static void gs_ide30 (GNODE node);
static void gs_ide28 (GNODE node);
static void gs_ide35 (void);
static void gs_ide34 (GEDGE edge);
static void gs_ide29 (void);
static void gs_ide27 (void);
static int gs_ide8 (GNODE v, GNODE w, GNODE z);
static void gs_ide33 (void);
static void gs_ide20 (GNODE node);
static void gs_ide5 (GNODE node);
static void gs_ide43 (ADJEDGE edge, GNODE node, int prio);
static void gs_ide46 (void);
static void gs_ide4 (GNODE v);
static GNODE gs_ide24 (void);
static int gs_ide49 (GNODE node1, GNODE node2);
static void gs_ide50 (GNODE node1, GNODE node2, int l);
static void gs_ide47 (GNODE node1, GNODE node2);
static int gs_ide48 (GNODE node1, GNODE node2);
static void gs_ide3 (GNODE v, GNLIST * l);
static GNODE gs_ide23 (GNLIST * l);
static void gs_ide37 (void);
static void gs_ide7 (GNLIST * nlist);
static int gs_ide12 (GNLIST nlist);
static int gs_ide39 (GNODE v, GNODE w, int prio);
static int gs_ide40 (GNODE v, GNODE w);
static int gs_ide38 (GNODE v, GNODE w);
static void gs_ide36 (GNODE v, GNODE w);
static void gs_ide41 (GNODE n, long *d, GNLIST * p);
static void gs_ide2 (void);
static void gs_ide52 (void);
static int gs_ide51 (GNODE v, int lab);
static void gs_ide13 (void);
static void gs_ide11 (void);
static void gs_ide6 (GNODE v, GNODE w, GNODE predw);
static void gs_ide32 (void);
static void gs_ide10 (GNODE n, ADJEDGE e, int l);
static void gs_ide31 (void);
static void gs_ide9 (ADJEDGE e);
static GNODE gs_ide14 (int t);
static ADJEDGE gs_ide15 (GNODE x, GNODE y, GEDGE e, int t);
int maxindeg;
int maxoutdeg;
DEPTH *layer = ((void *) 0);
int maxdepth = 0;
static int gs_ide42 = 0;
void
step1_main (void)
{
  int i;;;
  {
    if (!((dummylist == ((void *) 0))))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 91);
	exit (1);
      }
  };
  prepare_back_edges ();
  gs_ide35 ();
  insert_anchor_edges ();
  gs_ide29 ();
  gs_ide27 ();
  if (layout_flag == 3)
    gs_ide46 ();
  else if (layout_flag == 0)
    gs_ide37 ();
  else
    gs_ide33 ();
  if (edge_label_phase == 1)
    gs_ide2 ();
  if (fine_tune_layout == 1)
    gs_ide52 ();
  if (maxdepth + 2 > gs_ide42)
    {
      if (layer)
	free (layer);
      layer = (DEPTH *) malloc ((maxdepth + 2) * sizeof (struct depth_entry));
      if (!layer)
	Fatal_error ("memory exhausted", "");
      gs_ide42 = maxdepth + 2;
    }
  for (i = 0; i < maxdepth + 2; i++)
    {
      ((layer[i]).anz) = 0;
      ((layer[i]).predlist) = ((void *) 0);
      ((layer[i]).succlist) = ((void *) 0);
      ((layer[i]).resort_necessary) = 1;
    } gs_ide13 ();
  gs_ide32 ();
  gs_ide31 ();
  if (layout_flag == 20)
    {;
      layout_flag = tree_main ();
      if (layout_flag != 20)
	{
	  (void) fprintf (stderr, "\nThis is not a downward tree. ");
	  (void) fprintf (stderr, "Continuing with normal layout\n");
	}
    }
  calc_number_reversions ();
  if (layout_flag != 20)
    {
      gs_ide11 ();;
    }
}
static GNODE gs_ide44;
static GNODE gs_ide45;
static void
gs_ide30 (GNODE node)
{
  GNODE h, *hp;
  {
    if (!((node)))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 115);
	exit (1);
      }
  };;
  if (((node)->next))
    ((((node)->next))->before) = ((node)->before);
  else
    nodelistend = ((node)->before);
  if (((node)->before))
    ((((node)->before))->next) = ((node)->next);
  else
    nodelist = ((node)->next);
  h = gs_ide44;
  hp = &gs_ide44;
  while (h)
    {
      if (((h)->refnum) >= ((node)->refnum))
	break;
      hp = &(((h)->next));
      h = ((h)->next);
    }
  *hp = node;
  if (h)
    ((node)->before) = ((h)->before);
  else
    ((node)->before) = gs_ide45;
  ((node)->next) = h;
  if (h)
    ((h)->before) = node;
  else
    gs_ide45 = node;
}
static GNODE gs_ide21;
static GNODE gs_ide22;
static void
gs_ide28 (GNODE node)
{
  GNODE h, *hp;
  {
    if (!((node)))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 135);
	exit (1);
      }
  };;
  if (((node)->next))
    ((((node)->next))->before) = ((node)->before);
  else
    nodelistend = ((node)->before);
  if (((node)->before))
    ((((node)->before))->next) = ((node)->next);
  else
    nodelist = ((node)->next);
  h = gs_ide21;
  hp = &gs_ide21;
  while (h)
    {
      if (((h)->refnum) >= ((node)->refnum))
	break;
      hp = &(((h)->next));
      h = ((h)->next);
    }
  *hp = node;
  if (h)
    ((node)->before) = ((h)->before);
  else
    ((node)->before) = gs_ide22;
  ((node)->next) = h;
  if (h)
    ((h)->before) = node;
  else
    gs_ide22 = node;
}
static void
gs_ide35 (void)
{
  GNODE node, nxt_node;;
  gs_ide44 = ((void *) 0);
  gs_ide45 = ((void *) 0);
  gs_ide21 = ((void *) 0);
  gs_ide22 = ((void *) 0);
  node = nodelist;
  while (node)
    {
      nxt_node = ((node)->next);
      if (!((node)->pred))
	gs_ide30 (node);
      else if (!((node)->succ))
	gs_ide28 (node);
      node = nxt_node;
    }
  if (gs_ide44)
    {
      if (nodelist)
	((nodelist)->before) = gs_ide45;
      ((gs_ide45)->next) = nodelist;
      nodelist = gs_ide44;
      if (!nodelistend)
	nodelistend = gs_ide45;
    }
  if (gs_ide21)
    {
      if (nodelistend)
	((nodelistend)->next) = gs_ide21;
      ((gs_ide21)->before) = nodelistend;
      nodelistend = gs_ide22;
      if (!nodelist)
	nodelist = gs_ide21;
    }
}
void
insert_anchor_edges (void)
{
  GEDGE edge;;
  {
    if (!((dummylist == ((void *) 0))))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 170);
	exit (1);
      }
  };
  edge = edgelist;
  while (edge)
    {
      if ((((edge)->anchor) <= 64) && (((edge)->anchor) > 0)
	  && (!((edge)->invisible)))
	gs_ide34 (edge);
      edge = ((edge)->next);
    }
  edge = tmpedgelist;
  while (edge)
    {
      if ((((edge)->anchor) <= 64) && (((edge)->anchor) > 0)
	  && (!((edge)->invisible)))
	gs_ide34 (edge);
      edge = ((edge)->internal_next);
    }
}







static void
gs_ide34 (GEDGE edge)
{
  GEDGE h;
  GNODE v;
  CONNECT c1, c2;;
  if ((G_orientation == 1) || (G_orientation == 2))
    {
      G_orientation = 0;
      if (!silent)
	{
	  (void) fprintf (stderr, "Orientation ignored, because");
	  (void) fprintf (stderr, " edge attribute `anchor' used !\n");
	}
    }
  c1 = ((((edge)->start))->connection);
  if (!c1)
    {
      v = gs_ide14 (-1);
      ((v)->invisible) = 0;
      ((v)->level) = ((((edge)->start))->level);
      ((v)->nhorder) = ((((edge)->start))->nhorder);
      ((v)->anchordummy) = 1;
      h =
	tmpedgealloc (((edge)->linestyle), ((edge)->thickness),
		      ((edge)->eclass), 200, ((edge)->color),
		      ((edge)->labelcolor), 0, ((edge)->arrowsize2), 0,
		      ((edge)->arrowstyle2), ((edge)->arrowcolor1),
		      ((edge)->arrowcolor2), ((edge)->horder));
      ((h)->anchor) = 66;
      ((h)->start) = ((edge)->start);
      ((h)->end) = v;
      ((h)->label) = ((void *) 0);
      c1 = connectalloc (((h)->start));
      ((c1)->target) = v;
      ((c1)->edge) = h;
      c2 = connectalloc (v);
      ((c2)->target) = ((h)->start);
      ((c2)->edge) = h;
    }
  v = ((c1)->target);
  {
    if (!((v)))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 205);
	exit (1);
      }
  };
  {
    if (!((((v)->anchordummy))))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 205);
	exit (1);
      }
  };
  h =
    tmpedgealloc (((edge)->linestyle), ((edge)->thickness), ((edge)->eclass),
		  ((edge)->priority), ((edge)->color), ((edge)->labelcolor),
		  ((edge)->arrowsize1), ((edge)->arrowsize2),
		  ((edge)->arrowstyle1), ((edge)->arrowstyle2),
		  ((edge)->arrowcolor1), ((edge)->arrowcolor2),
		  ((edge)->horder));
  ((h)->anchor) = -((edge)->anchor);
  ((h)->start) = v;
  ((h)->end) = ((edge)->end);
  ((h)->label) = ((edge)->label);
  delete_adjedge (edge);
  ((edge)->invisible) = 0;
  create_adjedge (h);
}

void
prepare_back_edges (void)
{
  ADJEDGE e;
  ADJEDGE a1, a2;;
  e = back_edge_list;
  while (e)
    {
      if (!((((e)->kante))->invisible))
	revert_edge (((e)->kante));
      else if (((((e)->kante))->labelnode))
	{
	  a1 = ((((((e)->kante))->labelnode))->succ);
	  a2 = ((((((e)->kante))->labelnode))->pred);
	  if (a1)
	    if (!((((a1)->kante))->invisible))
	      revert_edge (((a1)->kante));
	  if (a2)
	    if (!((((a2)->kante))->invisible))
	      revert_edge (((a2)->kante));
	}
      e = ((e)->next);
    }
}
static void
gs_ide27 (void)
{
  GNODE v;
  ADJEDGE edge1;
  ADJEDGE edge;
  CONNECT c1, c2;
  int connection_possible, invisible;;
  edge1 = bent_near_edge_list;
  while (edge1)
    {
      invisible = ((((edge1)->kante))->invisible);
      v = ((((edge1)->kante))->labelnode);
      if (v)
	{
	  edge = ((v)->succ);
	  if (!edge)
	    invisible = 1;
	  else
	    invisible = ((((edge)->kante))->invisible);
	  edge = ((v)->pred);
	  if (!edge)
	    invisible |= 1;
	  else
	    invisible |= ((((edge)->kante))->invisible);
	}
      else if (!invisible)
	{
	  if (G_displayel == 1)
	    v = create_labelnode (((edge1)->kante));
	  else
	    {
	      v = gs_ide14 (-1);
	      ((v)->invisible) = 0;
	    }
	  ((v)->level) = (((((((edge1)->kante))->start)))->level);
	  ((v)->nhorder) = (((((((edge1)->kante))->start)))->nhorder);
	  edge =
	    gs_ide15 (v, (((((edge1)->kante))->end)), ((edge1)->kante), 1);
	  ((((edge)->kante))->label) = ((void *) 0);
	  edge =
	    gs_ide15 ((((((edge1)->kante))->start)), v, ((edge1)->kante), 0);
	  ((((edge)->kante))->label) = ((void *) 0);
	  ((((edge)->kante))->priority) = 0;
	  delete_adjedge (((edge1)->kante));
	  ((((edge1)->kante))->invisible) = 0;
	}
      if (!invisible)
	{
	  c1 = (((((((edge)->kante))->start)))->connection);
	  c2 = (((((((edge)->kante))->end)))->connection);
	  connection_possible = 1;
	  if ((c1) && (((c1)->target)) && (((c1)->target2)))
	    connection_possible = 0;
	  if ((c2) && (((c2)->target)) && (((c2)->target2)))
	    connection_possible = 0;
	  if (gs_ide8
	      ((((((edge)->kante))->end)), ((void *) 0),
	       (((((edge)->kante))->start))))
	    connection_possible = 0;
	  if (connection_possible)
	    {
	      if (!c1)
		{
		  c1 = connectalloc ((((((edge)->kante))->start)));
		  ((c1)->target) = (((((edge)->kante))->end));
		  ((c1)->edge) = ((edge)->kante);
		}
	      else if (!((c1)->target2))
		{
		  ((c1)->target2) = (((((edge)->kante))->end));
		  ((c1)->edge2) = ((edge)->kante);
		}
	      if (!c2)
		{
		  c2 = connectalloc ((((((edge)->kante))->end)));
		  ((c2)->target) = (((((edge)->kante))->start));
		  ((c2)->edge) = ((edge)->kante);
		}
	      else if (!((c2)->target2))
		{
		  ((c2)->target2) = (((((edge)->kante))->start));
		  ((c2)->edge2) = ((edge)->kante);
		}
	      delete_adjedge (((edge)->kante));
	      ((((edge)->kante))->invisible) = 0;
	    }
	  else if (!silent)
	    {
	      (void) fprintf (stderr, "Nearedge connection (");
	      if ((((((((edge)->kante))->start)))->title)[0])
		(void) fprintf (stderr, "%s",
				(((((((edge)->kante))->start)))->title));
	      (void) fprintf (stderr, " , ");
	      if ((((((((edge)->kante))->end)))->title)[0])
		(void) fprintf (stderr, "%s",
				(((((((edge)->kante))->end)))->title));
	      (void) fprintf (stderr, ") ignored ! Sorry !\n");
	    }
	}
      edge1 = ((edge1)->next);
}}
static void
gs_ide29 (void)
{
  ADJEDGE edge;
  CONNECT c1, c2;
  int connection_possible;;
  edge = near_edge_list;
  while (edge)
    {
      if (!((((edge)->kante))->invisible))
	{
	  c1 = (((((((edge)->kante))->start)))->connection);
	  c2 = (((((((edge)->kante))->end)))->connection);
	  connection_possible = 1;
	  if ((c1) && (((c1)->target)) && (((c1)->target2)))
	    connection_possible = 0;
	  if ((c2) && (((c2)->target)) && (((c2)->target2)))
	    connection_possible = 0;
	  if (gs_ide8
	      ((((((edge)->kante))->end)), ((void *) 0),
	       (((((edge)->kante))->start))))
	    connection_possible = 0;
	  if (connection_possible)
	    {
	      if (!c1)
		{
		  c1 = connectalloc ((((((edge)->kante))->start)));
		  ((c1)->target) = (((((edge)->kante))->end));
		  ((c1)->edge) = ((edge)->kante);
		}
	      else if (!((c1)->target2))
		{
		  ((c1)->target2) = (((((edge)->kante))->end));
		  ((c1)->edge2) = ((edge)->kante);
		}
	      if (!c2)
		{
		  c2 = connectalloc ((((((edge)->kante))->end)));
		  ((c2)->target) = (((((edge)->kante))->start));
		  ((c2)->edge) = ((edge)->kante);
		}
	      else if (!((c2)->target2))
		{
		  ((c2)->target2) = (((((edge)->kante))->start));
		  ((c2)->edge2) = ((edge)->kante);
		}
	      if (((((((((edge)->kante))->start)))->level) >= 0)
		  && ((((((((edge)->kante))->end)))->level) >= 0)
		  && ((((((((edge)->kante))->start)))->level) !=
		      (((((((edge)->kante))->end)))->level) >= 0))
		{
		  if (!silent)
		    {
		      (void) fprintf (stderr, "Nearedge connection (");
		      if ((((((((edge)->kante))->start)))->title)[0])
			(void) fprintf (stderr, "%s",
					(((((((edge)->kante))->start)))->
					 title));
		      (void) fprintf (stderr, " , ");
		      if ((((((((edge)->kante))->end)))->title)[0])
			(void) fprintf (stderr, "%s",
					(((((((edge)->kante))->end)))->
					 title));
		      (void) fprintf (stderr,
				      "): level of target ignored ! Sorry !\n");
		    }
		}
	      if ((((((((edge)->kante))->start)))->level) >= 0)
		{
		  (((((((edge)->kante))->end)))->level) =
		    (((((((edge)->kante))->start)))->level);
		}
	      if ((((((((edge)->kante))->end)))->level) >= 0)
		{
		  (((((((edge)->kante))->start)))->level) =
		    (((((((edge)->kante))->end)))->level);
		}
	      delete_adjedge (((edge)->kante));
	      ((((edge)->kante))->invisible) = 0;
	    }
	  else if (!silent)
	    {
	      (void) fprintf (stderr, "Nearedge connection (");
	      if ((((((((edge)->kante))->start)))->title)[0])
		(void) fprintf (stderr, "%s",
				(((((((edge)->kante))->start)))->title));
	      (void) fprintf (stderr, " , ");
	      if ((((((((edge)->kante))->end)))->title)[0])
		(void) fprintf (stderr, "%s",
				(((((((edge)->kante))->end)))->title));
	      (void) fprintf (stderr, ") ignored ! Sorry !\n");
	    }
	}
      edge = ((edge)->next);
}}
static int
gs_ide8 (GNODE v, GNODE w, GNODE z)
{
  CONNECT c;
  int r;;
  if (!near_edge_layout)
    return (1);
  if (!v)
    return (0);
  if (v == z)
    return (1);
  r = 0;
  c = ((v)->connection);
  if (!c)
    return (0);
  if (((c)->target) && (((c)->target) != w))
    r |= gs_ide8 (((c)->target), v, z);
  if (((c)->target2) && (((c)->target2) != w))
    r |= gs_ide8 (((c)->target2), v, z);
  return (r);
}
static long gs_ide0;
static int gs_ide1;







static void
gs_ide33 (void)
{
  GNODE node;
  int depth1;;
  gs_ide0 = 1L;
  maxdepth = 0;
  gs_wait_message ('p');
  node = nodelist;
  while (node)
    {
      if (!((node)->markiert))
	{
	  gs_ide1 = 0;
	  gs_ide20 (node);
	}
      node = ((node)->next);
    }




  node = labellist;
  while (node)
    {
      if (!((node)->markiert))
	{
	  if (!((0)))
	    {
	      (void) fprintf (stderr,
			      "Assertion failed: file \"%s\", line %d\n",
			      "step1.c", 427);
	      exit (1);
	    }
	};
      node = ((node)->next);
    }


  if (layout_flag == 12)
    return;
  if (layout_flag == 20)
    return;
  if (G_timelimit > 0)
    if (test_timelimit (30))
      {
	gs_wait_message ('t');
	return;
      }
  depth1 = maxdepth;
  gs_wait_message ('p');
  node = nodelist;
  while (node)
    {
      ((node)->markiert) = 0;
      node = ((node)->next);
    }
  node = labellist;
  while (node)
    {
      ((node)->markiert) = 0;
      node = ((node)->next);
    }
  node = dummylist;
  while (node)
    {
      ((node)->markiert) = 0;
      node = ((node)->next);
    }
  gs_ide0 = 1L;
  maxdepth = 0;
  node = nodelist;
  while (node)
    {
      if (!((node)->markiert))
	{
	  gs_ide1 = 0;
	  gs_ide5 (node);
	}
      node = ((node)->next);
    }
  node = labellist;
  while (node)
    {
      if (!((node)->markiert))
	{
	  if (!((0)))
	    {
	      (void) fprintf (stderr,
			      "Assertion failed: file \"%s\", line %d\n",
			      "step1.c", 441);
	      exit (1);
	    }
	};
      node = ((node)->next);
    }


  if ((layout_flag == 1) && (depth1 <= maxdepth))
    return;
  if ((layout_flag == 2) && (depth1 >= maxdepth))
    return;
  gs_wait_message ('p');
  node = nodelist;
  while (node)
    {
      ((node)->markiert) = 0;
      node = ((node)->next);
    }
  node = labellist;
  while (node)
    {
      ((node)->markiert) = 0;
      node = ((node)->next);
    }
  node = dummylist;
  while (node)
    {
      ((node)->markiert) = 0;
      node = ((node)->next);
    }
  gs_ide0 = 1L;
  maxdepth = 0;
  node = nodelist;
  while (node)
    {
      if (!((node)->markiert))
	{
	  gs_ide1 = 0;
	  gs_ide20 (node);
	}
      node = ((node)->next);
    }
  node = labellist;
  while (node)
    {
      if (!((node)->markiert))
	{
	  if (!((0)))
	    {
	      (void) fprintf (stderr,
			      "Assertion failed: file \"%s\", line %d\n",
			      "step1.c", 455);
	      exit (1);
	    }
	};
      node = ((node)->next);
    }


}

static void
gs_ide20 (GNODE node)
{
  GNODE kn;
  ADJEDGE edge;
  int priority;
  {
    if (!((node)))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 463);
	exit (1);
      }
  };;
  if (((node)->markiert))
    return;
  ((node)->markiert) = 1;
  ((node)->dfsnum) = gs_ide0++;
  if (((node)->level) >= 0)
    gs_ide1 = ((node)->level);
  ((node)->tiefe) = gs_ide1;
  maxdepth = (gs_ide1 > maxdepth) ? gs_ide1 : maxdepth;
  if (((node)->connection))
    {
      if (((((node)->connection))->target))
	gs_ide20 (((((node)->connection))->target));
      if (((((node)->connection))->target2))
	gs_ide20 (((((node)->connection))->target2));
    }
  priority = 1;
  while (priority > -1)
    {
      priority = -1;
      edge = ((node)->succ);
      while (edge)
	{
	  {
	    if (!(((((((edge)->kante))->start)) == node)))
	      {
		(void) fprintf (stderr,
				"Assertion failed: file \"%s\", line %d\n",
				"step1.c", 476);
		exit (1);
	      }
	  };
	  kn = (((((edge)->kante))->end));
	  if ((!((kn)->markiert))
	      && (((((edge)->kante))->priority) > priority))
	    priority = ((((edge)->kante))->priority);
	  edge = ((edge)->next);
	}
      if (priority == -1)
	break;
      edge = ((node)->succ);
      while (edge)
	{
	  if (((((edge)->kante))->priority) != priority)
	    {
	      edge = ((edge)->next);
	      continue;
	    }
	  {
	    if (!(((((((edge)->kante))->start)) == node)))
	      {
		(void) fprintf (stderr,
				"Assertion failed: file \"%s\", line %d\n",
				"step1.c", 486);
		exit (1);
	      }
	  };
	  kn = (((((edge)->kante))->end));
	  if (!((kn)->markiert))
	    {
	      gs_ide1++;
	      gs_ide20 (kn);
	      gs_ide1 = ((node)->tiefe);
	    }
	  else
	    {
	      if (kn == node)
		(((((edge)->kante))->kantenart)) = 'S';
	    }
	  edge = ((edge)->next);
	}
    }
}
static void
gs_ide5 (GNODE node)
{
  GNODE kn;
  ADJEDGE edge;
  int priority;
  {
    if (!((node)))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 498);
	exit (1);
      }
  };;
  if (((node)->markiert))
    return;
  ((node)->markiert) = 1;
  ((node)->dfsnum) = gs_ide0++;
  if (((node)->level) >= 0)
    gs_ide1 = ((node)->level);
  ((node)->tiefe) = gs_ide1;
  maxdepth = (gs_ide1 > maxdepth) ? gs_ide1 : maxdepth;
  if (((node)->connection))
    {
      if (((((node)->connection))->target))
	gs_ide5 (((((node)->connection))->target));
      if (((((node)->connection))->target2))
	gs_ide5 (((((node)->connection))->target2));
    }
  priority = 1;
  while (priority > -1)
    {
      priority = -1;
      edge = ((node)->succ);
      while (edge)
	{
	  {
	    if (!(((((((edge)->kante))->start)) == node)))
	      {
		(void) fprintf (stderr,
				"Assertion failed: file \"%s\", line %d\n",
				"step1.c", 511);
		exit (1);
	      }
	  };
	  kn = (((((edge)->kante))->end));
	  if ((!((kn)->markiert))
	      && (((((edge)->kante))->priority) > priority))
	    priority = ((((edge)->kante))->priority);
	  edge = ((edge)->next);
	}
      if (priority == -1)
	break;
      gs_ide43 (((node)->succ), node, priority);
    }
}
static void
gs_ide43 (ADJEDGE edge, GNODE node, int priority)
{
  GNODE kn;;
  if (!edge)
    return;
  gs_ide43 (((edge)->next), node, priority);
  if (((((edge)->kante))->priority) != priority)
    return;
  kn = (((((edge)->kante))->end));
  if (!((kn)->markiert))
    {
      gs_ide1++;
      gs_ide5 (kn);
      gs_ide1 = ((node)->tiefe);
    }
  else
    {
      if (kn == node)
	(((((edge)->kante))->kantenart)) = 'S';
    }
}
static GNLIST gs_ide54;
static GNLIST gs_ide53;
static void
gs_ide4 (GNODE v)
{
  GNLIST h;;
  if (gs_ide53)
    {
      h = gs_ide53;
      gs_ide53 = ((gs_ide53)->next);
    }
  else
    h = tmpnodelist_alloc ();
  ((h)->node) = v;
  ((h)->next) = gs_ide54;
  gs_ide54 = h;
}



static GNODE
gs_ide24 (void)
{
  GNLIST h;;
  h = gs_ide54;
  if (h)
    {
      gs_ide54 = ((h)->next);
      ((h)->next) = gs_ide53;
      gs_ide53 = h;
      return (((h)->node));
    }
  return (((void *) 0));
}



static void
gs_ide46 (void)
{
  GNODE v;
  int not_ready, actlevel;;
  gs_ide54 = ((void *) 0);
  gs_ide53 = ((void *) 0);
  v = nodelist;
  while (v)
    {
      if (gs_ide48 (v, v) == 0)
	gs_ide4 (v);
      v = ((v)->next);
    }
  maxdepth = 0;
  gs_wait_message ('p');
  not_ready = 1;
  while (not_ready)
    {
      while ((v = gs_ide24 ()) != ((void *) 0))
	{
	  actlevel = gs_ide49 (v, v);
	  if (((v)->level) >= 0)
	    actlevel = ((v)->level);
	  if (maxdepth < actlevel)
	    maxdepth = actlevel;
	  gs_ide50 (v, v, actlevel);
	  gs_ide47 (v, v);
	}
      gs_wait_message ('p');
      not_ready = 0;
      v = nodelist;
      while (v && !not_ready)
	{
	  if (!((v)->markiert))
	    {
	      gs_ide4 (v);
	      not_ready = 1;
	    }
	  v = ((v)->next);
	}
      v = labellist;
      while (v && !not_ready)
	{
	  if (!((v)->markiert))
	    {
	      gs_ide4 (v);
	      not_ready = 1;
	    }
	  v = ((v)->next);
	}
      v = dummylist;
      while (v && !not_ready)
	{
	  if (!((v)->markiert))
	    {
	      gs_ide4 (v);
	      not_ready = 1;
	    }
	  v = ((v)->next);
	}
    }
}
static int
gs_ide49 (GNODE node1, GNODE node2)
{
  int result, h;
  ADJEDGE a;
  CONNECT c;;
  result = 0;
  a = ((node1)->pred);
  while (a)
    {
      if ((((((a)->kante))->start)) == node1)
	(((((a)->kante))->kantenart)) = 'S';
      else if ((((((((a)->kante))->start)))->markiert))
	{
	  if ((((((((a)->kante))->start)))->tiefe) >= result)
	    result = (((((((a)->kante))->start)))->tiefe) + 1;
	}
      a = ((a)->next);
    }
  c = ((node1)->connection);
  if (c && ((c)->target) && (((c)->target) != node2))
    {
      h = gs_ide49 (((c)->target), node1);
      if (h > result)
	result = h;
    }
  if (c && ((c)->target2) && (((c)->target2) != node2))
    {
      h = gs_ide49 (((c)->target2), node1);
      if (h > result)
	result = h;
    }
  return (result);
}
static void
gs_ide50 (GNODE node1, GNODE node2, int level)
{
  CONNECT c;;
  if ((((node1)->level) >= 0) && (level != ((node1)->level)))
    {
      if (!silent)
	{
	  (void) fprintf (stderr, "Level specification ignored, ");
	  (void) fprintf (stderr, "because nearedge was specified !\n");
	}
    }
  ((node1)->tiefe) = level;
  ((node1)->markiert) = 1;
  c = ((node1)->connection);
  if (c && ((c)->target) && (((c)->target) != node2))
    gs_ide50 (((c)->target), node1, level);
  if (c && ((c)->target2) && (((c)->target2) != node2))
    gs_ide50 (((c)->target2), node1, level);
}
static void
gs_ide47 (GNODE node1, GNODE node2)
{
  ADJEDGE a;
  CONNECT c;;
  a = ((node1)->succ);
  while (a)
    {
      if ((gs_ide48 ((((((a)->kante))->end)), (((((a)->kante))->end))) == 0)
	  && (!(((((((a)->kante))->end)))->markiert)))
	gs_ide4 ((((((a)->kante))->end)));
      a = ((a)->next);
    }
  c = ((node1)->connection);
  if (c && ((c)->target) && (((c)->target) != node2))
    gs_ide47 (((c)->target), node1);
  if (c && ((c)->target2) && (((c)->target2) != node2))
    gs_ide47 (((c)->target2), node1);
}
static int
gs_ide48 (GNODE node1, GNODE node2)
{
  int result;
  ADJEDGE a;
  CONNECT c;;
  result = 0;
  a = ((node1)->pred);
  while (a)
    {
      if (!(((((((a)->kante))->start)))->markiert))
	result++;
      a = ((a)->next);
    }
  c = ((node1)->connection);
  if (c && ((c)->target) && (((c)->target) != node2))
    result += gs_ide48 (((c)->target), node1);
  if (c && ((c)->target2) && (((c)->target2) != node2))
    result += gs_ide48 (((c)->target2), node1);
  return (result);
}
static GNLIST gs_ide25;
static void
gs_ide3 (GNODE v, GNLIST * l)
{
  GNLIST h;;
  if (gs_ide53)
    {
      h = gs_ide53;
      gs_ide53 = ((gs_ide53)->next);
    }
  else
    h = tmpnodelist_alloc ();
  ((h)->node) = v;
  ((h)->next) = *l;
  *l = h;
}



static GNODE
gs_ide23 (GNLIST * l)
{
  GNLIST h;;
  h = *l;
  if (h)
    {
      *l = ((h)->next);
      ((h)->next) = gs_ide53;
      gs_ide53 = h;
      return (((h)->node));
    }
  return (((void *) 0));
}



static void
gs_ide37 (void)
{
  GNODE v;;
  gs_ide53 = ((void *) 0);
  gs_ide25 = ((void *) 0);
  maxdepth = 1;
  v = nodelist;
  while (v)
    {
      if (!((v)->invisible))
	gs_ide3 (v, &gs_ide25);
      ((v)->tiefe) = 1;
      v = ((v)->next);
    }
  v = labellist;
  while (v)
    {
      gs_ide3 (v, &gs_ide25);
      ((v)->tiefe) = 1;
      v = ((v)->next);
    }
  v = dummylist;
  while (v)
    {
      gs_ide3 (v, &gs_ide25);
      ((v)->tiefe) = 1;
      v = ((v)->next);
    }
  gs_ide7 (&gs_ide25);
}
static void
gs_ide7 (GNLIST * nlist)
{
  GNODE v;
  GNLIST h;
  GNLIST open_scc_list;
  long mydfsnum;;



  h = *nlist;
  while (h)
    {
      v = ((h)->node);
      ((v)->markiert) = ((v)->tiefe) = 0;
      ((v)->weights) = ((v)->weightp) = 0L;






      h = ((h)->next);
    }



  open_scc_list = ((void *) 0);
  mydfsnum = 0;
  gs_wait_message ('p');
  v = gs_ide23 (nlist);
  while (v)
    {
      gs_ide41 (v, &mydfsnum, &open_scc_list);
      v = gs_ide23 (nlist);
    }
}



static void
gs_ide41 (GNODE node, long *dfsnum, GNLIST * open_sccp)
{
  GNODE kn;
  GNLIST h;
  GNLIST closed_scc_list;
  ADJEDGE edge;
  int mylevel;
  GNODE actrev;
  int degree;
  int minindeg;
  int maxoutdeg;
  int maxpreindeg;
  int minlevel;
  {
    if (!((node)))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 693);
	exit (1);
      }
  };;
  if (((node)->markiert))
    return;
  ((node)->markiert) = 1;
  ((node)->weightp) = 1L;
  ((node)->dfsnum) = *dfsnum;
  ((node)->weights) = *dfsnum;
  (*dfsnum)++;
  gs_ide3 (node, open_sccp);
  if (((node)->connection))
    {
      if (((((node)->connection))->target))
	{
	  kn = ((((node)->connection))->target);
	  gs_ide41 (kn, dfsnum, open_sccp);
	  if ((((kn)->weightp)) && (((kn)->weights) < ((node)->weights)))
	    ((node)->weights) = ((kn)->weights);
	}
      if (((((node)->connection))->target2))
	{
	  kn = ((((node)->connection))->target2);
	  gs_ide41 (kn, dfsnum, open_sccp);
	  if ((((kn)->weightp)) && (((kn)->weights) < ((node)->weights)))
	    ((node)->weights) = ((kn)->weights);
	}
    }
  edge = ((node)->pred);
  while (edge)
    {
      {
	if (!(((((((edge)->kante))->end)) == node)))
	  {
	    (void) fprintf (stderr,
			    "Assertion failed: file \"%s\", line %d\n",
			    "step1.c", 715);
	    exit (1);
	  }
      };
      kn = (((((edge)->kante))->start));
      if (((kn)->tiefe) == 0)
	{
	  gs_ide41 (kn, dfsnum, open_sccp);
	  if ((((kn)->weightp)) && (((kn)->weights) < ((node)->weights)))
	    ((node)->weights) = ((kn)->weights);
	}
      edge = ((edge)->next);
    }
  if (((node)->weights) == ((node)->dfsnum))
    {
      h = closed_scc_list = *open_sccp;
      {
	if (!((h)))
	  {
	    (void) fprintf (stderr,
			    "Assertion failed: file \"%s\", line %d\n",
			    "step1.c", 724);
	    exit (1);
	  }
      };
      kn = ((h)->node);
      while (kn != node)
	{
	  ((kn)->weightp) = 0L;
	  h = ((h)->next);
	  {
	    if (!((h)))
	      {
		(void) fprintf (stderr,
				"Assertion failed: file \"%s\", line %d\n",
				"step1.c", 726);
		exit (1);
	      }
	  };
	  kn = ((h)->node);
	}
      {
	if (!((kn == node)))
	  {
	    (void) fprintf (stderr,
			    "Assertion failed: file \"%s\", line %d\n",
			    "step1.c", 727);
	    exit (1);
	  }
      };
      ((node)->weightp) = 0L;
      *open_sccp = ((h)->next);
      ((h)->next) = 0;
      minlevel = -1;
      h = closed_scc_list;
      while (h)
	{
	  node = ((h)->node);
	  edge = ((node)->pred);
	  while (edge)
	    {
	      kn = (((((edge)->kante))->start));
	      mylevel = ((kn)->tiefe);
	      if (mylevel > minlevel)
		minlevel = mylevel;
	      edge = ((edge)->next);
	    }
	  h = ((h)->next);
	}
      {
	if (!((closed_scc_list)))
	  {
	    (void) fprintf (stderr,
			    "Assertion failed: file \"%s\", line %d\n",
			    "step1.c", 746);
	    exit (1);
	  }
      };
      degree = gs_ide12 (closed_scc_list);
      if (degree)
	{




	  minlevel++;
	  kn = gs_ide23 (&closed_scc_list);
	  while (kn)
	    {
	      if (((kn)->level) >= 0)
		((kn)->tiefe) = ((kn)->level);
	      else
		((kn)->tiefe) = minlevel;
	      maxdepth =
		(((kn)->tiefe) > maxdepth) ? ((kn)->tiefe) : maxdepth;
	      kn = gs_ide23 (&closed_scc_list);
	    }
	  return;
	}
      h = closed_scc_list;
      while (h)
	{
	  ((((h)->node))->tiefe) = 2147483647;
	  h = ((h)->next);
	}
      actrev = ((closed_scc_list)->node);
      minindeg = 2147483647;
      maxoutdeg = 0;
      maxpreindeg = 0;
      h = closed_scc_list;
      while (h)
	{
	  node = ((h)->node);
	  degree = gs_ide39 (node, ((void *) 0), 1);
	  if (degree < minindeg)
	    {
	      minindeg = degree;
	      actrev = node;
	      h = ((h)->next);
	      continue;
	    }
	  else if (degree > minindeg)
	    {
	      h = ((h)->next);
	      continue;
	    }
	  degree = gs_ide38 (node, ((void *) 0));
	  if (degree > maxoutdeg)
	    {
	      maxoutdeg = degree;
	      actrev = node;
	      h = ((h)->next);
	      continue;
	    }
	  else if (degree < maxoutdeg)
	    {
	      h = ((h)->next);
	      continue;
	    }
	  degree = gs_ide40 (node, ((void *) 0));
	  if (degree > maxpreindeg)
	    {
	      maxpreindeg = degree;
	      actrev = node;
	    }
	  h = ((h)->next);
	}
      gs_ide36 (actrev, ((void *) 0));
      gs_ide7 (&closed_scc_list);
    }
}

static int
gs_ide12 (GNLIST nlist)
{
  GNODE v;
  GNLIST h;
  int res, count;
  CONNECT c;;
  {
    if (!((nlist)))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 785);
	exit (1);
      }
  };
  count = 0;
  res = 1;
  h = nlist;
  while (h)
    {
      count++;
      if (((((h)->node))->level) < 0)
	res = 0;
      h = ((h)->next);
    }
  if (res)
    return (1);
  if (count == 1)
    return (1);
  h = nlist;
  while (h)
    {
      {
	if (!((((((h)->node))->markiert) == 1)))
	  {
	    (void) fprintf (stderr,
			    "Assertion failed: file \"%s\", line %d\n",
			    "step1.c", 790);
	    exit (1);
	  }
      };
      ((((h)->node))->markiert) = 0;
      h = ((h)->next);
    } count = 1;
  ((((nlist)->node))->markiert) = 1;
  while (count)
    {
      count = 0;
      h = nlist;
      while (h)
	{
	  v = ((h)->node);
	  if (((v)->markiert))
	    {
	      c = ((v)->connection);
	      if ((c) && ((c)->edge))
		{
		  if (!((((((c)->edge))->start))->markiert))
		    count++;
		  if (!((((((c)->edge))->end))->markiert))
		    count++;
		  ((((((c)->edge))->start))->markiert) = 1;
		  ((((((c)->edge))->end))->markiert) = 1;
		}
	      if ((c) && ((c)->edge2))
		{
		  if (!((((((c)->edge2))->start))->markiert))
		    count++;
		  if (!((((((c)->edge2))->end))->markiert))
		    count++;
		  ((((((c)->edge2))->start))->markiert) = 1;
		  ((((((c)->edge2))->end))->markiert) = 1;
		}
	    }
	  h = ((h)->next);
	}
    }
  res = 1;
  h = nlist;
  while (h)
    {
      if (!((((h)->node))->markiert))
	{
	  res = 0;
	  break;
	}
      h = ((h)->next);
    }
  h = nlist;
  while (h)
    {
      ((((h)->node))->markiert) = 1;
      h = ((h)->next);
    }
  return (res);
}
static int
gs_ide39 (GNODE v, GNODE w, int prio)
{
  int degree;
  ADJEDGE e;
  CONNECT c;
  degree = 0;
  e = ((v)->succ);
  while (e)
    {
      if ((((((((e)->kante))->end)))->tiefe) == 2147483647)
	{
	  if (prio)
	    degree += ((((e)->kante))->priority);
	  else
	    degree++;
	}
      e = ((e)->next);
    }
  c = ((v)->connection);
  if (!c)
    return (degree);
  if (((c)->target) && (w != ((c)->target)))
    degree += gs_ide39 (((c)->target), v, prio);
  if (((c)->target2) && (w != ((c)->target2)))
    degree += gs_ide39 (((c)->target2), v, prio);
  return (degree);
}
static int
gs_ide40 (GNODE v, GNODE w)
{
  int degree;
  ADJEDGE e;
  CONNECT c;
  degree = 0;
  e = ((v)->succ);
  while (e)
    {
      if ((((((((e)->kante))->end)))->tiefe) == 2147483647)
	{
	  degree += gs_ide39 ((((((e)->kante))->start)), ((void *) 0), 0);
	}
      e = ((e)->next);
    } c = ((v)->connection);
  if (!c)
    return (degree);
  if (((c)->target) && (w != ((c)->target)))
    degree += gs_ide40 (((c)->target), v);
  if (((c)->target2) && (w != ((c)->target2)))
    degree += gs_ide40 (((c)->target2), v);
  return (degree);
}
static int
gs_ide38 (GNODE v, GNODE w)
{
  int degree;
  ADJEDGE e;
  CONNECT c;
  degree = 0;
  e = ((v)->pred);
  while (e)
    {
      if ((((((((e)->kante))->start)))->tiefe) == 2147483647)
	{
	  degree++;
	}
      e = ((e)->next);
    }
  c = ((v)->connection);
  if (!c)
    return (degree);
  if (((c)->target) && (w != ((c)->target)))
    degree += gs_ide38 (((c)->target), v);
  if (((c)->target2) && (w != ((c)->target2)))
    degree += gs_ide38 (((c)->target2), v);
  return (degree);
}
static void
gs_ide36 (GNODE v, GNODE w)
{
  ADJEDGE e, en;
  CONNECT c;
  e = ((v)->succ);
  while (e)
    {
      en = ((e)->next);
      if ((((((((e)->kante))->end)))->tiefe) == 2147483647)
	{
	  revert_edge (((e)->kante));
	}
      e = en;
    }
  c = ((v)->connection);
  if (!c)
    return;
  if (((c)->target) && (w != ((c)->target)))
    gs_ide36 (((c)->target), v);
  if (((c)->target2) && (w != ((c)->target2)))
    gs_ide36 (((c)->target2), v);
}
static void
gs_ide2 (void)
{
  GNODE v, vl, vt;
  ADJEDGE edge, edgenext;;
  v = nodelist;
  while (v)
    {
      ((v)->markiert) = 0;
      v = ((v)->next);
    }
  v = dummylist;
  while (v)
    {
      ((v)->markiert) = 0;
      v = ((v)->next);
    }
  v = labellist;
  while (v)
    {
      ((v)->markiert) = 0;
      v = ((v)->next);
    }
  maxdepth = 2 * maxdepth;
  v = nodelist;
  while (v)
    {
      if (!((v)->markiert))
	{
	  ((v)->tiefe) = 2 * ((v)->tiefe);
	  ((v)->markiert) = 1;
	}
      else
	{
	  if (!((0)))
	    {
	      (void) fprintf (stderr,
			      "Assertion failed: file \"%s\", line %d\n",
			      "step1.c", 889);
	      exit (1);
	    }
	};;
      v = ((v)->next);
    } v = dummylist;
  while (v)
    {
      if (!((v)->markiert))
	{
	  ((v)->tiefe) = 2 * ((v)->tiefe);
	  ((v)->markiert) = 1;
	}
      else
	{
	  if (!((0)))
	    {
	      (void) fprintf (stderr,
			      "Assertion failed: file \"%s\", line %d\n",
			      "step1.c", 894);
	      exit (1);
	    }
	};;
      v = ((v)->next);
    } v = labellist;
  while (v)
    {
      if (!((v)->markiert))
	{
	  ((v)->tiefe) = 2 * ((v)->tiefe);
	  ((v)->markiert) = 1;
	}
      else
	{
	  if (!((0)))
	    {
	      (void) fprintf (stderr,
			      "Assertion failed: file \"%s\", line %d\n",
			      "step1.c", 899);
	      exit (1);
	    }
	};;
      v = ((v)->next);
    } v = nodelist;
  while (v)
    {
      edge = ((v)->succ);
      while (edge)
	{
	  edgenext = ((edge)->next);
	  if (((((edge)->kante))->label))
	    {
	      vl = create_labelnode (((edge)->kante));
	      vt = (((((edge)->kante))->end));
	      ((vl)->tiefe) =
		((((((((edge)->kante))->start)))->tiefe) +
		 (((((((edge)->kante))->end)))->tiefe)) / 2;
	      (void) gs_ide15 (v, vl, ((edge)->kante), 0);
	      (void) gs_ide15 (vl, vt, ((edge)->kante), 1);
	      delete_adjedge (((edge)->kante));
	    }
	  edge = edgenext;
	} v = ((v)->next);
    } v = tmpnodelist;
  while (v)
    {
      edge = ((v)->succ);
      while (edge)
	{
	  edgenext = ((edge)->next);
	  if (((((edge)->kante))->label))
	    {
	      vl = create_labelnode (((edge)->kante));
	      vt = (((((edge)->kante))->end));
	      ((vl)->tiefe) =
		((((((((edge)->kante))->start)))->tiefe) +
		 (((((((edge)->kante))->end)))->tiefe)) / 2;
	      (void) gs_ide15 (v, vl, ((edge)->kante), 0);
	      (void) gs_ide15 (vl, vt, ((edge)->kante), 1);
	      delete_adjedge (((edge)->kante));
	    }
	  edge = edgenext;
	} v = ((v)->next);
}}
static void
gs_ide52 (void)
{
  GNODE v;
  int changed, count;;
  count = 0;
  changed = 1;
  while (changed)
    {
      changed = 0;
      gs_wait_message ('p');
      if (G_timelimit > 0)
	if (test_timelimit (30))
	  {
	    gs_wait_message ('t');
	    return;
	  }
      v = nodelist;
      while (v)
	{
	  if (!((v)->connection))
	    changed += gs_ide51 (v, 0);
	  v = ((v)->next);
	}
      v = labellist;
      while (v)
	{
	  if (!((v)->connection))
	    changed += gs_ide51 (v, 1);
	  v = ((v)->next);
	}
      count++;
      if (count >= 50)
	return;
    }
}







static int
gs_ide51 (GNODE v, int lab)
{
  int nodelevel, leveldiff, nr_edges, nr_redges, changed, delta, hdelta;
  ADJEDGE edge, hedge;
  GNODE hh;;
  if (((v)->level) >= 0)
    return (0);
  nr_redges = nr_edges = leveldiff = 0;
  nodelevel = ((v)->tiefe);
  if ((!((v)->succ)) || (!((v)->pred)))
    delta = 1;
  else
    delta = 0;
  edge = ((v)->pred);
  while (edge)
    {
      nr_edges += ((((edge)->kante))->priority);
      nr_redges++;
      if ((((((((edge)->kante))->start)))->tiefe) != nodelevel)
	leveldiff +=
	  (((((edge)->kante))->priority) *
	   ((((((((edge)->kante))->start)))->tiefe) - nodelevel + delta));
      edge = ((edge)->next);
    }
  edge = ((v)->succ);
  while (edge)
    {
      nr_edges += ((((edge)->kante))->priority);
      nr_redges++;
      if ((((((((edge)->kante))->end)))->tiefe) != nodelevel)
	leveldiff +=
	  (((((edge)->kante))->priority) *
	   ((((((((edge)->kante))->end)))->tiefe) - nodelevel - delta));
      edge = ((edge)->next);
    }
  if (nr_redges == 0)
    {
      ((v)->tiefe) = 0;
      return (0);
    }
  if (nr_edges == 0)
    return (0);
  changed = 0;
  if (leveldiff / nr_edges <= -2)
    {
      changed = 1;
      nodelevel += (leveldiff / nr_edges);
    }
  else if (leveldiff / nr_edges > 0)
    {
      changed = 1;
      nodelevel += (leveldiff / nr_edges);
    }
  if (!changed)
    return (0);
  if ((layout_flag == 3) || (layout_flag == 0))
    {
      if (near_edge_layout)
	delta = 0;
      else
	delta = 1;
      if (nodelevel > ((v)->tiefe))
	{
	  edge = ((v)->succ);
	  while (edge)
	    {
	      if (((((((((edge)->kante))->end)))->tiefe) > ((v)->tiefe))
		  && (nodelevel >= (((((((edge)->kante))->end)))->tiefe)))
		nodelevel = (((((((edge)->kante))->end)))->tiefe) - delta;
	      edge = ((edge)->next);
	    }
	  edge = ((v)->pred);
	  while (edge)
	    {
	      if (((((((((edge)->kante))->start)))->tiefe) > ((v)->tiefe))
		  && (nodelevel >= (((((((edge)->kante))->start)))->tiefe)))
		nodelevel = (((((((edge)->kante))->start)))->tiefe) - delta;
	      edge = ((edge)->next);
	    }
	  if (nodelevel <= ((v)->tiefe))
	    return (0);
	}
      if (nodelevel < ((v)->tiefe))
	{
	  edge = ((v)->succ);
	  while (edge)
	    {
	      if (((((((((edge)->kante))->end)))->tiefe) < ((v)->tiefe))
		  && (nodelevel <= (((((((edge)->kante))->end)))->tiefe)))
		nodelevel = (((((((edge)->kante))->end)))->tiefe) + delta;
	      edge = ((edge)->next);
	    }
	  edge = ((v)->pred);
	  while (edge)
	    {
	      if (((((((((edge)->kante))->start)))->tiefe) < ((v)->tiefe))
		  && (nodelevel <= (((((((edge)->kante))->start)))->tiefe)))
		nodelevel = (((((((edge)->kante))->start)))->tiefe) + delta;
	      edge = ((edge)->next);
	    }
	  if (nodelevel >= ((v)->tiefe))
	    return (0);
	}
      edge = ((v)->pred);
      while (edge)
	{
	  if ((((((edge)->kante))->kantenart)) != 'R')
	    {
	      if ((nodelevel < (((((((edge)->kante))->start)))->tiefe))
		  && (((v)->tiefe) >=
		      (((((((edge)->kante))->start)))->tiefe)))
		return (0);
	    }
	  edge = ((edge)->next);
	}
      edge = ((v)->succ);
      while (edge)
	{
	  if ((((((edge)->kante))->kantenart)) != 'R')
	    {
	      if ((nodelevel > (((((((edge)->kante))->end)))->tiefe))
		  && (((v)->tiefe) <= (((((((edge)->kante))->end)))->tiefe)))
		return (0);
	    }
	  edge = ((edge)->next);
	}
    }
  else
    {
      edge = ((v)->pred);
      while (edge)
	{
	  if (nodelevel == (((((((edge)->kante))->start)))->tiefe))
	    return (0);
	  edge = ((edge)->next);
	}
      edge = ((v)->succ);
      while (edge)
	{
	  if (nodelevel == (((((((edge)->kante))->end)))->tiefe))
	    return (0);
	  edge = ((edge)->next);
	}
    }
  delta = 0;
  edge = ((v)->pred);
  while (edge)
    {
      hh = (((((edge)->kante))->start));
      if (nodelevel == ((hh)->tiefe))
	{
	  delta++;
	  if (((hh)->connection))
	    return (0);
	  hdelta = 0;
	  hedge = ((hh)->pred);
	  while (hedge)
	    {
	      if (((hh)->tiefe) == (((((((hedge)->kante))->start)))->tiefe))
		hdelta++;
	      hedge = ((hedge)->next);
	    }
	  hedge = ((hh)->succ);
	  while (hedge)
	    {
	      if (((hh)->tiefe) == (((((((hedge)->kante))->end)))->tiefe))
		hdelta++;
	      hedge = ((hedge)->next);
	    }
	  if (hdelta > 1)
	    return (0);
	}
      edge = ((edge)->next);
    }
  edge = ((v)->succ);
  while (edge)
    {
      hh = (((((edge)->kante))->end));
      if (nodelevel == ((hh)->tiefe))
	{
	  delta++;
	  if (((hh)->connection))
	    return (0);
	  hdelta = 0;
	  hedge = ((hh)->pred);
	  while (hedge)
	    {
	      if (((hh)->tiefe) == (((((((hedge)->kante))->start)))->tiefe))
		hdelta++;
	      hedge = ((hedge)->next);
	    }
	  hedge = ((hh)->succ);
	  while (hedge)
	    {
	      if (((hh)->tiefe) == (((((((hedge)->kante))->end)))->tiefe))
		hdelta++;
	      hedge = ((hedge)->next);
	    }
	  if (hdelta > 1)
	    return (0);
	}
      edge = ((edge)->next);
    }
  if (delta > 2)
    return (0);
  if (nodelevel < 0)
    return (0);
  if (nodelevel > maxdepth)
    return (0);
  if (((v)->tiefe) != nodelevel)
    changed = 1;
  ((v)->tiefe) = nodelevel;
  return (changed);
}


static void
gs_ide13 (void)
{
  GNODE h;
  GNLIST hl;
  int t;;
  h = nodelist;
  while (h)
    {
      t = ((h)->tiefe);
      {
	if (!((t <= maxdepth)))
	  {
	    (void) fprintf (stderr,
			    "Assertion failed: file \"%s\", line %d\n",
			    "step1.c", 1084);
	    exit (1);
	  }
      };
      hl = tmpnodelist_alloc ();
      ((hl)->next) = ((layer[t]).succlist);
      ((layer[t]).succlist) = hl;
      ((hl)->node) = h;
      h = ((h)->next);
    } h = labellist;
  while (h)
    {
      t = ((h)->tiefe);
      {
	if (!((t <= maxdepth + 1)))
	  {
	    (void) fprintf (stderr,
			    "Assertion failed: file \"%s\", line %d\n",
			    "step1.c", 1088);
	    exit (1);
	  }
      };
      hl = tmpnodelist_alloc ();
      ((hl)->next) = ((layer[t]).succlist);
      ((layer[t]).succlist) = hl;
      ((hl)->node) = h;
      h = ((h)->next);
    } h = dummylist;
  while (h)
    {
      t = ((h)->tiefe);
      {
	if (!((t <= maxdepth + 1)))
	  {
	    (void) fprintf (stderr,
			    "Assertion failed: file \"%s\", line %d\n",
			    "step1.c", 1092);
	    exit (1);
	  }
      };
      hl = tmpnodelist_alloc ();
      ((hl)->next) = ((layer[t]).succlist);
      ((layer[t]).succlist) = hl;
      ((hl)->node) = h;
      h = ((h)->next);
}}
static void
gs_ide11 (void)
{
  int i;
  GNLIST n, hl;
  GNODE node;
  ADJEDGE edge;
  int backward_connection;
  int forward_connection;
  CONNECT c;;
  maxindeg = maxoutdeg = 0;
  for (i = 0; i <= maxdepth + 1; i++)
    {
      n = ((layer[i]).succlist);
      while (n)
	{
	  ((((n)->node))->markiert) = 0;
	  n = ((n)->next);
	}
      n = ((layer[i]).succlist);
      {
	if (!((((layer[i]).predlist) == ((void *) 0))))
	  {
	    (void) fprintf (stderr,
			    "Assertion failed: file \"%s\", line %d\n",
			    "step1.c", 1107);
	    exit (1);
	  }
      };
      while (n)
	{
	  node = ((n)->node);
	  edge = ((node)->succ);
	  backward_connection = 0;
	  forward_connection = 0;
	  c = ((node)->connection);
	  if (c)
	    {
	      if (((((c)->edge)) && (((((c)->edge))->end) != ((c)->target))))
		backward_connection = 1;
	      if (((((c)->edge2))
		   && (((((c)->edge2))->end) != ((c)->target2))))
		backward_connection = 1;
	      if (((((c)->edge)) && (((((c)->edge))->end) == ((c)->target))))
		forward_connection = 1;
	      if (((((c)->edge2))
		   && (((((c)->edge2))->end) == ((c)->target2))))
		forward_connection = 1;
	    }
	  if ((forward_connection) && (!backward_connection)
	      && (((((n)->node))->markiert) == 0))
	    gs_ide6 (node, node, ((void *) 0));
	  if ((!backward_connection) && (((((n)->node))->markiert) == 0))
	    {
	      hl = tmpnodelist_alloc ();
	      ((hl)->next) = ((layer[i]).predlist);
	      ((layer[i]).predlist) = hl;
	      ((hl)->node) = node;
	    }
	  edge = ((node)->succ);
	  while (edge)
	    {
	      ((node)->outdegree)++;
	      {
		if (!(((((((((edge)->kante))->end)))->tiefe) >= i)))
		  {
		    (void) fprintf (stderr,
				    "Assertion failed: file \"%s\", line %d\n",
				    "step1.c", 1124);
		    exit (1);
		  }
	      };
	      edge = ((edge)->next);
	    } edge = ((node)->pred);
	  while (edge)
	    {
	      ((node)->indegree)++;
	      edge = ((edge)->next);
	    }
	  if (((node)->outdegree) > maxoutdeg)
	    maxoutdeg = ((node)->outdegree);
	  if (((node)->indegree) > maxindeg)
	    maxindeg = ((node)->indegree);
	  n = ((n)->next);
	}
    }
}
static void
gs_ide6 (GNODE v, GNODE w, GNODE predw)
{
  ADJEDGE edge;
  CONNECT c;;
  if (v != w)
    ((w)->markiert) = 1;
  if (v == w)
    {
      ((w)->savesucc) = ((w)->succ);
      ((v)->savepred) = ((v)->pred);
    }
  edge = ((w)->succ);
  if (v == w)
    ((v)->succ) = ((void *) 0);
  while (edge)
    {
      succedgealloc (v, ((edge)->kante));
      (((((edge)->kante))->start)) = v;
      edge = ((edge)->next);
    }
  edge = ((w)->pred);
  if (v == w)
    ((v)->pred) = ((void *) 0);
  while (edge)
    {
      prededgealloc (v, ((edge)->kante));
      (((((edge)->kante))->end)) = v;
      edge = ((edge)->next);
    }
  c = ((w)->connection);
  if (!c)
    return;
  if (((c)->target) && (((c)->target) != predw))
    gs_ide6 (v, ((c)->target), w);
  if (((c)->target2) && (((c)->target2) != predw))
    gs_ide6 (v, ((c)->target2), w);
}
static void
gs_ide32 (void)
{
  int i;
  GNLIST li;
  GNODE node;
  ADJEDGE edge, nextedge;
  GNODE d1, d2;
  ADJEDGE e1, e2, e3, e4;
  GEDGE a1, a2;;
  for (i = 0; i <= maxdepth; i++)
    {
      li = ((layer[i]).succlist);
      while (li)
	{
	  node = ((li)->node);
	  edge = ((node)->succ);
	  while (edge)
	    {
	      {
		if (!(((((((edge)->kante))->start)) == node)))
		  {
		    (void) fprintf (stderr,
				    "Assertion failed: file \"%s\", line %d\n",
				    "step1.c", 1167);
		    exit (1);
		  }
	      };
	      nextedge = ((edge)->next);
	      gs_ide10 (node, edge, i);
	      edge = nextedge;
	    } li = ((li)->next);
    }} node = labellist;
  while (node)
    {
      edge = ((node)->succ);
      if (edge && (((edge)->next)))
	{
	  a1 = ((edge)->kante);
	  a2 = ((((edge)->next))->kante);
	  d1 = gs_ide14 (((node)->tiefe));
	  d2 = gs_ide14 (((node)->tiefe));
	  e1 = gs_ide15 (node, d1, a1, 0);
	  e2 = gs_ide15 (d1, ((a1)->end), a1, 1);
	  e3 = gs_ide15 (node, d2, a2, 0);
	  e4 = gs_ide15 (d2, ((a2)->end), a2, 1);
	  gs_ide10 ((((((e1)->kante))->start)), e1, ((node)->tiefe));
	  gs_ide10 ((((((e2)->kante))->start)), e2, ((node)->tiefe));
	  gs_ide10 ((((((e3)->kante))->start)), e3, ((node)->tiefe));
	  gs_ide10 ((((((e4)->kante))->start)), e4, ((node)->tiefe));
	  delete_adjedge (a1);
	  delete_adjedge (a2);
	}
      edge = ((node)->pred);
      if (edge && (((edge)->next)))
	{
	  a1 = ((edge)->kante);
	  a2 = ((((edge)->next))->kante);
	  d1 = gs_ide14 (((node)->tiefe));
	  d2 = gs_ide14 (((node)->tiefe));
	  e1 = gs_ide15 (d1, node, a1, 1);
	  e2 = gs_ide15 (((a1)->start), d1, a1, 0);
	  e3 = gs_ide15 (d2, node, a2, 1);
	  e4 = gs_ide15 (((a2)->start), d2, a2, 0);
	  gs_ide10 ((((((e1)->kante))->start)), e1, ((node)->tiefe));
	  gs_ide10 ((((((e2)->kante))->start)), e2, ((node)->tiefe) - 1);
	  gs_ide10 ((((((e3)->kante))->start)), e3, ((node)->tiefe));
	  gs_ide10 ((((((e4)->kante))->start)), e4, ((node)->tiefe) - 1);
	  delete_adjedge (a1);
	  delete_adjedge (a2);
	}
      node = ((node)->next);
    }
}
static void
gs_ide10 (GNODE node, ADJEDGE edge, int level)
{
  int edgelen;
  int i, j;
  GNODE d1, d2;
  ADJEDGE e1, e2, e3;
  CONNECT c1, c2;
  int connection_possible, lab_set;;
  {
    if (!((node)))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 1215);
	exit (1);
      }
  };
  {
    if (!((edge)))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 1215);
	exit (1);
      }
  };
  {
    if (!((((edge)->kante))))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 1216);
	exit (1);
      }
  };
  {
    if (!((((node)->tiefe) == level)))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 1216);
	exit (1);
      }
  };
  {
    if (!(((((((edge)->kante))->start)) == node)))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 1218);
	exit (1);
      }
  };
  edgelen = (((((((edge)->kante))->end))->tiefe)) - level;
  if (edgelen < 0)
    {
      e1 = revert_edge (((edge)->kante));
      gs_ide10 ((((((e1)->kante))->start)), e1,
		(((((((e1)->kante))->start)))->tiefe));
    }
  else if (edgelen == 0)
    {
      if ((((((edge)->kante))->kantenart)) == 'R')
	{
	  e1 = revert_edge (((edge)->kante));
	  gs_ide10 ((((((e1)->kante))->start)), e1,
		    (((((((e1)->kante))->start)))->tiefe));
	}
      else if ((((((edge)->kante))->start)) == (((((edge)->kante))->end)))
	{
	  {
	    if (!(((((((edge)->kante))->end)) == node)))
	      {
		(void) fprintf (stderr,
				"Assertion failed: file \"%s\", line %d\n",
				"step1.c", 1236);
		exit (1);
	      }
	  };
	  {
	    if (!((level <= maxdepth)))
	      {
		(void) fprintf (stderr,
				"Assertion failed: file \"%s\", line %d\n",
				"step1.c", 1237);
		exit (1);
	      }
	  };
	  d1 = gs_ide14 (level + 1);
	  d2 = gs_ide14 (level + 1);
	  ((d1)->nhorder) = ((d2)->nhorder) = ((((edge)->kante))->horder);
	  e1 = gs_ide15 (node, d1, ((edge)->kante), 0);
	  e2 = gs_ide15 (d1, d2, ((edge)->kante), 2);
	  e3 = gs_ide15 (d2, node, ((edge)->kante), 1);
	  ((((e2)->kante))->label) = ((((edge)->kante))->label);
	  gs_ide10 ((((((e2)->kante))->start)), e2,
		    (((((((e2)->kante))->start)))->tiefe));
	  gs_ide10 ((((((e3)->kante))->start)), e3,
		    (((((((e3)->kante))->start)))->tiefe));
	  delete_adjedge (((edge)->kante));
	}
      else
	{
	  c1 = ((node)->connection);
	  c2 = (((((((edge)->kante))->end)))->connection);
	  connection_possible = 1;
	  if ((c1) && (((c1)->target)) && (((c1)->target2)))
	    connection_possible = 0;
	  if ((c2) && (((c2)->target)) && (((c2)->target2)))
	    connection_possible = 0;
	  if (gs_ide8
	      ((((((edge)->kante))->end)), ((void *) 0),
	       (((((edge)->kante))->start))))
	    connection_possible = 0;
	  if (connection_possible)
	    {
	      if (!c1)
		{
		  c1 = connectalloc (node);
		  ((c1)->target) = (((((edge)->kante))->end));
		  ((c1)->edge) = ((edge)->kante);
		}
	      else if (!((c1)->target2))
		{
		  ((c1)->target2) = (((((edge)->kante))->end));
		  ((c1)->edge2) = ((edge)->kante);
		}
	      if (!c2)
		{
		  c2 = connectalloc ((((((edge)->kante))->end)));
		  ((c2)->target) = node;
		  ((c2)->edge) = ((edge)->kante);
		}
	      else if (!((c2)->target2))
		{
		  ((c2)->target2) = node;
		  ((c2)->edge2) = ((edge)->kante);
		}
	      delete_adjedge (((edge)->kante));
	      ((((edge)->kante))->invisible) = 0;
	    }
	  else
	    {
	      if (level <= maxdepth)
		d1 = gs_ide14 (level + 1);
	      else if (level > 0)
		d1 = gs_ide14 (level - 1);
	      else
		{
		  {
		    if (!((0)))
		      {
			(void) fprintf (stderr,
					"Assertion failed: file \"%s\", line %d\n",
					"step1.c", 1284);
			exit (1);
		      }
		  };
		} ((d1)->nhorder) = ((((edge)->kante))->horder);
	      e1 = gs_ide15 (node, d1, ((edge)->kante), 0);
	      e2 =
		gs_ide15 (d1, (((((edge)->kante))->end)), ((edge)->kante), 1);
	      ((((e2)->kante))->label) = ((((edge)->kante))->label);
	      gs_ide10 ((((((e1)->kante))->start)), e1,
			(((((((e1)->kante))->start)))->tiefe));
	      gs_ide10 ((((((e2)->kante))->start)), e2,
			(((((((e2)->kante))->start)))->tiefe));
	      delete_adjedge (((edge)->kante));
    }}}
  else if (edgelen == 1)
    {
    }
  else if (edgelen > 1)
    {
      d1 = node;
      j = lab_set = 0;
      for (i = 1; i < edgelen; i++)
	{
	  d2 = gs_ide14 (level + i);
	  ((d2)->nhorder) = ((((edge)->kante))->horder);
	  e1 = gs_ide15 (d1, d2, ((edge)->kante), j);
	  if (i == (edgelen + 1) / 2)
	    {
	      ((((e1)->kante))->label) = ((((edge)->kante))->label);
	      lab_set = 1;
	    }
	  d1 = d2;
	  j = 2;
	}
      e1 = gs_ide15 (d1, (((((edge)->kante))->end)), ((edge)->kante), 1);
      if (!lab_set)
	((((e1)->kante))->label) = ((((edge)->kante))->label);
      delete_adjedge (((edge)->kante));
    }
}
ADJEDGE
revert_edge (GEDGE edge)
{
  GNODE h;
  char hh;;
  delete_adjedge (edge);
  h = ((edge)->start);
  ((edge)->start) = ((edge)->end);
  ((edge)->end) = h;
  if (((edge)->kantenart) == 'R')
    ((edge)->kantenart) = 'U';
  else if (((edge)->kantenart) == 'S')
    ((edge)->kantenart) = 'S';
  else
    ((edge)->kantenart) = 'R';
  hh = ((edge)->arrowsize1);
  ((edge)->arrowsize1) = ((edge)->arrowsize2);
  ((edge)->arrowsize2) = hh;
  hh = ((edge)->arrowcolor1);
  ((edge)->arrowcolor1) = ((edge)->arrowcolor2);
  ((edge)->arrowcolor2) = hh;
  hh = ((edge)->arrowstyle1);
  ((edge)->arrowstyle1) = ((edge)->arrowstyle2);
  ((edge)->arrowstyle2) = hh;
  create_adjedge (edge);
  return (((((edge)->start))->succ));
}
static ADJEDGE
gs_ide15 (GNODE start, GNODE end, GEDGE edge, int arrow)
{
  GEDGE h;
  h =
    tmpedgealloc (((edge)->linestyle), ((edge)->thickness), ((edge)->eclass),
		  ((edge)->priority), ((edge)->color), ((edge)->labelcolor),
		  ((edge)->arrowsize1), ((edge)->arrowsize2),
		  ((edge)->arrowstyle1), ((edge)->arrowstyle2),
		  ((edge)->arrowcolor1), ((edge)->arrowcolor2),
		  ((edge)->horder));
  ((h)->label) = ((edge)->label);
  ((h)->anchor) = ((edge)->anchor);
  ((h)->start) = start;
  ((h)->end) = end;
  switch (arrow)
    {
    case 0:
      ((h)->arrowstyle1) = 0;
      ((h)->arrowsize1) = 0;
      ((h)->label) = ((void *) 0);
      break;
    case 1:
      ((h)->arrowstyle2) = 0;
      ((h)->arrowsize2) = 0;
      ((h)->label) = ((void *) 0);
      break;
    case 2:
      ((h)->arrowstyle1) = 0;
      ((h)->arrowsize1) = 0;
      ((h)->label) = ((void *) 0);
      ((h)->arrowstyle2) = 0;
      ((h)->arrowsize2) = 0;
      ((h)->label) = ((void *) 0);
      break;
    }
  if (((edge)->kantenart) == 'S')
    ((h)->kantenart) = 'U';
  else
    ((h)->kantenart) = ((edge)->kantenart);
  if (start == end)
    ((h)->kantenart) = 'S';
  create_adjedge (h);
  return (((((h)->start))->succ));
}
static GNODE
gs_ide14 (int t)
{
  GNLIST hl;
  GNODE v;;
  {
    if (!((t <= maxdepth + 1)))
      {
	(void) fprintf (stderr, "Assertion failed: file \"%s\", line %d\n",
			"step1.c", 1370);
	exit (1);
      }
  };
  v = tmpnodealloc (0, -1, -1, 0, -1, G_color, G_color, G_color, 1, 1, -1);
  ((v)->title) = "";
  ((v)->label) = "";
  ((v)->tiefe) = t;
  ((v)->nhorder) = -1;
  ((v)->before) = ((void *) 0);
  ((v)->next) = dummylist;
  if (dummylist)
    ((dummylist)->before) = v;
  dummylist = v;
  dummyanz++;
  if (t < 0)
    return (v);
  hl = tmpnodelist_alloc ();
  ((hl)->next) = ((layer[t]).succlist);
  ((layer[t]).succlist) = hl;
  ((hl)->node) = v;
  return (v);
}
static void
gs_ide31 (void)
{
  int i;
  GNLIST li;
  GNODE node;
  ADJEDGE edge, nextedge;;
  for (i = 0; i <= maxdepth; i++)
    {
      li = ((layer[i]).succlist);
      while (li)
	{
	  node = ((li)->node);
	  edge = ((node)->succ);
	  while (edge)
	    {
	      {
		if (!(((((((edge)->kante))->start)) == node)))
		  {
		    (void) fprintf (stderr,
				    "Assertion failed: file \"%s\", line %d\n",
				    "step1.c", 1390);
		    exit (1);
		  }
	      };
	      nextedge = ((edge)->next);
	      gs_ide9 (edge);
	      edge = nextedge;
	    } li = ((li)->next);
}}}







static void
gs_ide9 (ADJEDGE edge)
{
  ADJEDGE l, lnext;
  GNODE d1;
  ADJEDGE e1;
  GEDGE f1, f2;
  int ide, aside1, aside2, tide;;
  f1 = ((edge)->kante);
  l = (((((((edge)->kante))->start)))->succ);
  while (l)
    {
      lnext = ((l)->next);
      f2 = ((l)->kante);
      if (f1 != f2)
	{
	  tide = ide = aside1 = aside2 = 1;
	}
      else
	{
	  tide = ide = aside1 = aside2 = 0;
	}
      if (((f1)->start) != ((f2)->start))
	tide = 0;
      if (((f1)->end) != ((f2)->end))
	tide = 0;
      if (((f1)->linestyle) != ((f2)->linestyle))
	ide = 0;
      if (((f1)->thickness) > ((f2)->thickness))
	ide = 0;
      if (((f1)->priority) > ((f2)->priority))
	ide = 0;
      if (((f1)->horder) != ((f2)->horder))
	ide = 0;
      if (((f1)->eclass) != ((f2)->eclass))
	ide = 0;
      if (((f1)->color) != ((f2)->color))
	ide = 0;
      if (((f1)->arrowsize1) != ((f2)->arrowsize1))
	aside1 = 0;
      if (((f1)->arrowsize2) != ((f2)->arrowsize2))
	aside2 = 0;
      if (((f1)->arrowstyle1) != ((f2)->arrowstyle1))
	aside1 = 0;
      if (((f1)->arrowstyle2) != ((f2)->arrowstyle2))
	aside2 = 0;
      if (((f1)->arrowcolor1) != ((f2)->arrowcolor1))
	aside1 = 0;
      if (((f1)->arrowcolor2) != ((f2)->arrowcolor2))
	aside2 = 0;
      if (((f1)->anchor) != ((f2)->anchor))
	ide = 0;
      if (tide && ide && aside1 && aside2 && summarize_double_edges)
	{
	  delete_adjedge (f1);
	  return;
	}
      if (tide)
	{
	  d1 = gs_ide14 ((((((((l)->kante))->end)))->tiefe));
	  ((d1)->nhorder) = ((f1)->horder);
	  e1 = gs_ide15 ((((((edge)->kante))->start)), d1, f1, 0);
	  gs_ide10 ((((((e1)->kante))->start)), e1,
		    (((((((e1)->kante))->start)))->tiefe));
	  e1 = gs_ide15 (d1, (((((edge)->kante))->end)), ((edge)->kante), 1);
	  ((((e1)->kante))->label) = ((f1)->label);
	  gs_ide10 ((((((e1)->kante))->start)), e1,
		    (((((((e1)->kante))->start)))->tiefe));
	  delete_adjedge (f1);
	  return;
	}
      l = lnext;
    }
}
int number_reversions;
void
calc_number_reversions (void)
{
  GNODE v;
  ADJEDGE e;;
  number_reversions = 0;
  v = nodelist;
  while (v)
    {
      e = ((v)->pred);
      while (e)
	{
	  if ((((((e)->kante))->kantenart)) == 'R')
	    number_reversions++;
	  e = ((e)->next);
	}
      v = ((v)->next);
    }
  v = labellist;
  while (v)
    {
      e = ((v)->pred);
      while (e)
	{
	  if ((((((e)->kante))->kantenart)) == 'R')
	    number_reversions++;
	  e = ((e)->next);
	}
      v = ((v)->next);
    }
  v = dummylist;
  while (v)
    {
      e = ((v)->pred);
      while (e)
	{
	  if ((((((e)->kante))->kantenart)) == 'R')
	    number_reversions++;
	  e = ((e)->next);
	}
      v = ((v)->next);
    }
}
